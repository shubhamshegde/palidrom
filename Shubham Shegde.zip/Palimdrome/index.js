let isMatchingBrackets = function(str) {
    let stack = [];
    let map = {
        '(': ')',
        '[': ']',
        '{': '}'
    }

    for (let i = 0; i < str.length; i++) {
        if (str[i] === '(' || str[i] === '{' || str[i] === '[') {
            stack.push(str[i]);
        } else {
            let last = stack.pop();
            if (str[i] !== map[last]) { return false };
        }
    }
    if (stack.length !== 0) { return false };

    return true;
}

let json = require('C:/Users/HP/Desktop/Palimdrome/Input.json');

let myString = json.toString();
let outputArray = [];
let words = myString.split(",");
for (let index = 0; index < words.length; index++) {
    let tofunctionString = words[index].toString();
    pushedValue = isMatchingBrackets(tofunctionString);

    if (pushedValue == true) {
        outputArray.push("YES");
    } else {
        outputArray.push("NO");
    }
}

const fs = require('fs');
var alphabet = outputArray;
const jsonContent = JSON.stringify(alphabet);

fs.writeFile("Output.json", jsonContent, 'utf8', function(err) {
    if (err) {
        return console.log(err);
    }

    console.log("The file was saved!");
});